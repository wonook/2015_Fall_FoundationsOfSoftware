package fos

import scala.util.parsing.combinator.syntactical.StandardTokenParsers
import scala.util.parsing.input._

/** This object implements a parser and evaluator for the
 *  untyped lambda calculus found in Chapter 5 of
 *  the TAPL book.
 */
object Untyped extends StandardTokenParsers {
  lexical.delimiters ++= List("(", ")", "\\", ".")
  import lexical.Identifier

  /** t ::= x
          | '\' x '.' t
          | t t
          | '(' t ')'
   */
  def term: Parser[Term] =
    rep1(singleTerm) ^^ {case termlist => processTermList(termlist)}
  def singleTerm: Parser[Term] =
  ( ident ^^ {case e => Var(e)} |
    ("\\" ~> ident) ~ ("." ~> term) ^^ {case vr ~ t => Abs(vr, t)} |
    "(" ~> term <~ ")"
    )
  def processTermList(tl: List[Term]): Term = {
    if (tl.tail.isEmpty) tl.head
    else App(tl.head, processTermList(tl.tail))
  }

  // def v: Parser[Var] = ident ^^ { case e => Var(e) }
  // def abs: Parser[Abs] = ("\\" ~> ident) ~ ("." ~> term) ^^ { case x ~ t => Abs(x, t) }
  // def pTerm: Parser[Term] = "(" ~> term <~ ")"
  // def genTerm: Parser[Term] = { v | abs | pTerm }
  // def term: Parser[Term] = {
    // rep1(genTerm) ^^ { case list => (list.head /: list.tail)(App(_, _)) } |
      // failure("illegal start of term")
  // }

  /** <p>
   *    Alpha conversion: term <code>t</code> should be a lambda abstraction
   *    <code>\x. t</code>.
   *  </p>
   *  <p>
   *    All free occurences of <code>x</code> inside term <code>t/code>
   *    will be renamed to a unique name.
   *  </p>
   *
   *  @param t the given lambda abstraction.
   *  @return  the transformed term with bound variables renamed.
   */
  def alpha(t: Term): Term =
    t match {
      case Abs(v, t0) => Abs(v, processTerm(t0, v))
      case _ => t
    }
    def processTerm(t: Term, v: String): Term = {
      t match {
        case App(t1, t2) => App(processTerm(t1, v), processTerm(t2, v))
        case Abs(vr, t0) => Abs(vr, processTerm(t0, v))
        case Var(vr) if (vr == v) => Var(vr + "0")
        case _ => t
      }
    }

  /** Straight forward substitution method
   *  (see definition 5.3.5 in TAPL book).
   *  [x -> s]t
   *
   *  @param t the term in which we perform substitution
   *  @param x the variable name
   *  @param s the term we replace x with
   *  @return  ...
   */
  def subst(t: Term, x: String, s: Term): Term =
    t match {
      case Var(vr) if (vr == x) => s
      case Var(vr) if (vr != x) => t
      case Abs(vr, t0) if (vr == x) => t
      case Abs(vr, t0) if (vr != x && !(FV(s).exists((v: String) => v == vr))) => Abs(vr, subst(t0, x, s))
      case Abs(vr, t0) if (vr != x && FV(s).exists((v: String) => v == vr)) => subst(alpha(t), x, s)
      case App(t1, t2) => App(subst(t1, x, s), subst(t2, x, s))
      case _ => t
    }
    //Free Variable test
  def FV(t: Term): List[String] =
    t match {
      case Var(vr) => List(vr)
      case Abs(vr, t0) => FV(t0).filter((v: String) => v != vr)
      case App(t1, t2) => FV(t1):::FV(t2)
    }

  /** Term 't' does not match any reduction rule. */
  case class NoReductionPossible(t: Term) extends Exception(t.toString)

  /** Normal order (leftmost, outermost redex first).
   *
   *  @param t the initial term
   *  @return  the reduced term
   */
  def reduceNormalOrder(t: Term): Term =
    t match {
      case App(App(t1, t2), t3) => App(reduceNormalOrder(App(t1, t2)), t3)
      case App(Abs(vr, t0), t2) => subst(t0, vr, t2)
      case App(Var(vr), t2) => App(Var(vr), reduceNormalOrder(t2))
      case Abs(vr, t0) => Abs(vr, reduceNormalOrder(t0))
      case _ => throw new NoReductionPossible(t)
    }

  /** Call by value reducer. */
  def reduceCallByValue(t: Term): Term =
    t match {
      case App(Abs(vr, t0), Var(vr1)) => subst(t0, vr, Var(vr1))
      case App(Var(vr), t2) => App(reduceCallByValue(Var(vr)), t2)
      case _ => throw new NoReductionPossible(t)
    }

  /** Returns a stream of terms, each being one step of reduction.
   *
   *  @param t      the initial term
   *  @param reduce the method that reduces a term by one step.
   *  @return       the stream of terms representing the big reduction.
   */
  def path(t: Term, reduce: Term => Term): Stream[Term] =
    try {
      var t1 = reduce(t)
      Stream.cons(t, path(t1, reduce))
    } catch {
      case NoReductionPossible(_) =>
        Stream.cons(t, Stream.empty)
    }

  def main(args: Array[String]): Unit = {
    val stdin = new java.io.BufferedReader(new java.io.InputStreamReader(System.in))
    val tokens = new lexical.Scanner(stdin.readLine())
    phrase(term)(tokens) match {
      case Success(trees, _) =>
        println("normal order: ")
        for (t <- path(trees, reduceNormalOrder))
          println(t)
        println("call-by-value: ")
        for (t <- path(trees, reduceCallByValue))
          println(t)

      case e =>
        println(e)
    }
  }
}
